# NEXT_TASK

**Vai trò:** CLAUDE 5 — INTEGRATION & RELEASE (hoặc bất kỳ phiên có mạng và có API key thử).
**Mục tiêu:** xác thực với thế giới thật, rồi sửa lỗi phát hiện.

## Đọc trước
HANDOFF.md → PROGRESS.md → KNOWN_ISSUES.md → DECISIONS.md (D-015…D-018).

## Cần làm (theo thứ tự)
1. Chạy `npm install && npm test` và `npm run test:e2e` trên máy có mạng; ghi kết quả vào PROGRESS.md.
2. Thử `en.json` thật (hoặc ≥200 dòng đại diện): xem Classifier có loại nhầm/bỏ sót (KI-001). Sửa `src/core/classify/classify.ts` + thêm ca test.
3. Gọi API thật qua chế độ DIRECT với ~40 chuỗi (Pilot): kiểm tra (a) CORS của nhà cung cấp, (b) định dạng JSON trả về, (c) tỷ lệ QA đạt. Ghi số liệu thật vào KNOWN_ISSUES (KI-006). Điều chỉnh `src/core/translate/prompt.ts` nếu cần.
4. Deploy GitHub Pages (và/hoặc Netlify) theo README; đo timeout Netlify thực tế (KI-004) và chỉnh mặc định lô.
5. Thử trên iPhone Safari thật: tải file, dịch, đóng/mở lại tab, tải xuống file (KI-007).
6. Việc còn thiếu theo ưu tiên: LLM Review (SP-6.4), ảo hoá danh sách Editor, test migration IndexedDB, USER_GUIDE.md, security audit (SP-11.1).

## KHÔNG được
Đổi key/cấu trúc dữ liệu xuất; đổi `types.ts` mà không cập nhật CONTRACTS.md + CHANGELOG (BREAKING); dùng MockProvider trong luồng chạy thật.

## Hoàn thành khi
Có một vòng thật: en.json thật → vi.json xuất ra mở được trong game/công cụ đích, không mất key/placeholder.
