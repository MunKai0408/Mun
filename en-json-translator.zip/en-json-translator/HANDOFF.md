# HANDOFF

**Cập nhật:** 2026-11-13. **Trạng thái:** bản chạy được (MVP đầy đủ luồng chính), chưa deploy, chưa thử API thật.

## Đã làm
Toàn bộ lõi + giao diện + hàm Netlify + chế độ gọi AI trực tiếp (GitHub Pages) + trang điều phối tài khoản. Xem PROGRESS.md.

## Cấu trúc
- `src/` TypeScript → `tsc` → `site/js/` (đã commit, host tĩnh dùng được ngay).
- `src/core/*` hàm thuần; `src/services/*` orchestrator/AI/lưu trữ; `src/ui/*` giao diện (`app.ts` chính, `accounts.ts` điều phối tài khoản).
- `netlify/functions/translate.mjs` dùng lại `site/js/services/ai/provider.js` → **phải chạy `npm run build` trước khi deploy Functions** (netlify.toml đã gồm).
- `tests/*.test.mjs` (61 test) và `tests/e2e*.mjs` (Playwright, cần Playwright cài toàn cục).

## Lệnh
`npm install && npm test` · `npm start` · `npm run test:e2e`

## Việc người dùng cần làm
1. Tạo repo GitHub, đẩy toàn bộ thư mục này lên, bật Pages (Source: GitHub Actions) — xem README.
2. Vào Cài đặt → "Trực tiếp" → dán API key → "Kiểm tra kết nối".
3. Thử với một `en.json` nhỏ thật, báo lại lỗi/chuỗi dịch chưa ổn.

## Điều cần biết
- Lệch kế hoạch: không dùng React/Vite/Tailwind vì phiên làm việc không có mạng để cài gói (D-015). Có thể chuyển sau nếu cần; core không phụ thuộc UI.
- `CONTRACTS.md` có thêm phần "Thay đổi v1.1.0"; bản chuẩn thực thi là `src/contracts/types.ts`.
